
public interface GAInterface {
	boolean isValidGrade(double aGrade);
	
	void addGrade(double aGrade);
		
	void analyzeGrades();
		
	public String toString();
}
