
public class EasterTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.out.println(Easter.calculateEaster(2001));
		System.out.println(Easter.calculateEaster(2012));

}
}