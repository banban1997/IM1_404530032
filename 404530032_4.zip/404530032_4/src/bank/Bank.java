package bank;

import java.util.HashMap;

public class Bank {
	HashMap<Integer, BankAccount> BankList = new HashMap<Integer, BankAccount>();
	
	void addAccount (int _actNum, double _balance){
		if (_balance < 0)
			_balance = 0;
		BankList.put(_actNum, new BankAccount(_actNum, _balance));
		}
	
	void deposit(int _actNum, double _balance){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		try{
			tempAct.deposit(_balance);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	void withdraw(int _actNum, double _balance){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		try{
			tempAct.deposit(_balance);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	double getBalance(int _actNum){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		return tempAct.getBalance();
	}
	
	void suspendAccount(int _actNum){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		tempAct.suspend();
		
	}
	
	void reOpenAccount(int _actNum){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		tempAct.reOpen();
	}
	
	void closeAccount(int _actNum){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		tempAct.close();
	}
	
	String getAccountStatus(int _actNum){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		return tempAct.state;
	}
	
	String summarizeAccountTransaction(int _actNum){
		
		String s = new String();
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		
		s.equals("Account #" + _actNum + "transactions:\n" );
		s.equals(tempAct.getTransaction());
		s.equals("End of transactions\n");
		
		return s.toString();
	}
	
	String summarizeAllAccounts(){
		String s = new String();
		return s.toString();
	}
	
	
}
