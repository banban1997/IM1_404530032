package bank;

public interface BankInterface {
	void deposit(double amount) throws Exception;
	
	void addTransaction(double amount);
	
	void withdraw(double amount) throws Exception;
	
	boolean isOpen();
	
	boolean isSuspended();
	
	boolean isClosed();
	
	void reOpen();
	
	void suspend();
		
	void close ();
	
	String getTransaction();
	
	double getBalance();
	
	int retrieveNumberOfTransactions();

}
