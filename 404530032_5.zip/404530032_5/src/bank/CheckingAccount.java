package bank;

public class CheckingAccount extends BankAccount {
	CheckingAccount(int _actNum, double _Balance){
		super(_actNum,_Balance);
	}
	void withdraw(double amount){
		
	}
	public void deductFees() {
		
	}

}
