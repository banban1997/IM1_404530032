package bank;

import java.util.ArrayList;

public class BankAccount {
	int actNum;
	String state;
    double balance;
	ArrayList<Double> TransactionList;
	
	public BankAccount(){
		this(-1,-1);
	}
	
	public BankAccount(int _actNum){
		this(_actNum , 0);
	}

	public BankAccount(int _actNum, double _balance) {
		this.actNum = _actNum;
		this.state = "open";
		this.balance = _balance;
		this.TransactionList = new ArrayList<Double>();
	}
	
	void deposit(double amount) throws Exception{
		if (!this.isOpen()&& amount > 0 ){
			throw new Exception("transaction:" + this.actNum + " depositting ");
		}
		
		this.balance = amount + this.balance;
		addTransaction(amount);
	}

	private void addTransaction(double amount) {
		this.TransactionList.add(amount);
		
	}
	
	void withdraw(double amount) throws Exception{
		if (!this.isOpen() && amount > 0 && this.balance <= amount ){
			throw new Exception("transaction:" + this.actNum + " withdrawing");
		}
		this.balance = amount - this.balance;
		addTransaction(- amount);
	}
	
	private boolean isOpen(){
		return this.state.equalsIgnoreCase("open");
	}
	
	private boolean isSuspended(){
		return this.state.equalsIgnoreCase("suspended");
	}
	
	private boolean isClosed(){
		return this.state.equalsIgnoreCase("closed");
	}
	
	void reOpen(){
		this.state = "open";
	}
	
	void suspend(){
		this.state = "suspend";
	}
	
	void close (){
		this.state = "closed";
	}
	
	String getTransaction(){
		String s = new String();
		for(int i = 0;i <this.TransactionList.size(); i++){
			s.equals((i + 1) + ":" + this.TransactionList.get(i));
		}
		return s.toString();
	}
	double getBalance(int accountNumber2){
		return this.balance;
	}
	
	int retrieveNumberOfTransactions(){
		return this.TransactionList.size();
	}
	public boolean equals(Object o){
		if(this.balance < 0.01)
		return true;
		return false;
		
	}

}
