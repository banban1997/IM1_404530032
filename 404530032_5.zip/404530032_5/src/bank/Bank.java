package bank;

import java.util.HashMap;

public class Bank {
	HashMap<Integer, BankAccount> BankList = new HashMap<Integer, BankAccount>();
	
	void addCheckingAccount(int _actNum, double _balance){
		
	}
	
	void addSavingsAccount(int _actNum, double _balance, double interestRate){
		
	}
	
	void addInterest(int _actNum){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
	}
	
	void deductFees(int _actNum){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		
	}
	
	void transfer(int withdrawAcctNum, int depositAcctNum, double amount){
	
	}
	
	boolean areEqualAccounts(int accountNumber1, int accountNumber2){
		BankAccount tempAct = (BankAccount) BankList.get(accountNumber1);
		if(tempAct.getBalance(accountNumber1) == tempAct.getBalance(accountNumber2))
			return true;
		return false;		
	}
	void deposit(int _actNum, double _balance){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		try{
			tempAct.deposit(_balance);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	void withdraw(int _actNum, double _balance){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		try{
			tempAct.deposit(_balance);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	double getBalance(int _actNum){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		return tempAct.getBalance();
	}
	
	void suspendAccount(int _actNum){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		tempAct.suspend();
		
	}
	
	void reOpenAccount(int _actNum){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		tempAct.reOpen();
	}
	
	void closeAccount(int _actNum){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		tempAct.close();
	}
	
	String getAccountStatus(int _actNum){
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		return tempAct.state;
	}
	
	String summarizeAccountTransaction(int _actNum){
		
		String s = new String();
		BankAccount tempAct = (BankAccount) BankList.get(_actNum);
		
		s.equals("Account #" + _actNum + "transactions:\n" );
		s.equals(tempAct.getTransaction());
		s.equals("End of transactions\n");
		
		return s.toString();
	}
	
	String summarizeAllAccounts(){
		
		String s = new String();
		
		s.equals("Account\tBalance\t#Transactions\tStatus\n");
		
		for(BankAccount bank: BankList.values()){
			s.equals(bank.actNum + "\t");
			s.equals(bank.getBalance() + "\t");
			s.equals(bank.retrieveNumberOfTransactions() + "\t\t");
			s.equals(bank.state + "\n");
		}
		s.equals("End of Account Summary");

		return s.toString();
	}
	
	
}
