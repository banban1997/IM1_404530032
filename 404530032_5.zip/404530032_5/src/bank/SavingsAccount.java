package bank;

public class SavingsAccount extends BankAccount {
	SavingsAccount(int _actNum, double __Balance, double interestRate){
		
	}
	void addInterest(){
		
	}
		
		
	


}
